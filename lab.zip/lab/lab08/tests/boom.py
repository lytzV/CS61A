test = {
  'name': 'Boom',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'answer': 'n^4',
          'choices': [
            '1',
            'n',
            'log(n)',
            'n^2',
            'n^3',
            'n^4',
            'exponential'
          ],
          'hidden': False,
          'locked': False,
          'question': 'What is the order of growth in runtime for boom?'
        }
      ],
      'scored': False,
      'type': 'concept'
    }
  ]
}
