# Object Oriented Programming

class Fib():
    """A Fibonacci number.

    >>> start = Fib()
    >>> start
    0
    >>> start.next()
    1
    >>> start.next().next()
    1
    >>> start.next().next().next()
    2
    >>> start.next().next().next().next()
    3
    >>> start.next().next().next().next().next()
    5
    >>> start.next().next().next().next().next().next()
    8
    >>> start.next().next().next().next().next().next() # Ensure start isn't changed
    8
    """

    def __init__(self, value=0):
        self.value = value

    def next(self):
        "*** YOUR CODE HERE ***"
        if(self.value==0):
            self.prev=1
        next_one=Fib(self.value+self.prev)
        next_one.prev=self.value
        return next_one
    def __repr__(self):
        return str(self.value)

class VendingMachine:
    """A vending machine that vends some product for some price.

    >>> v = VendingMachine('candy', 10)
    >>> v.vend()
    'Machine is out of stock.'
    >>> v.deposit(15)
    'Machine is out of stock. Here is your $15.'
    >>> v.restock(2)
    'Current candy stock: 2'
    >>> v.vend()
    'You must deposit $10 more.'
    >>> v.deposit(7)
    'Current balance: $7'
    >>> v.vend()
    'You must deposit $3 more.'
    >>> v.deposit(5)
    'Current balance: $12'
    >>> v.vend()
    'Here is your candy and $2 change.'
    >>> v.deposit(10)
    'Current balance: $10'
    >>> v.vend()
    'Here is your candy.'
    >>> v.deposit(15)
    'Machine is out of stock. Here is your $15.'

    >>> w = VendingMachine('soda', 2)
    >>> w.restock(3)
    'Current soda stock: 3'
    >>> w.restock(3)
    'Current soda stock: 6'
    >>> w.deposit(2)
    'Current balance: $2'
    >>> w.vend()
    'Here is your soda.'
    """
    "*** YOUR CODE HERE ***"
    def __init__(self,name,price):
        self.name=name
        self.price=price
        self.current_stock=0
        self.money_deposited=0

    def vend(self):
        if not self.current_stock:
            return 'Machine is out of stock.'
        else:
            if self.money_deposited<self.price:
                return 'You must deposit ${0} more.'.format(self.price-self.money_deposited)
            elif self.money_deposited==self.price:
                self.current_stock-=1
                self.money_deposited=0
                return 'Here is your {0}.'.format(self.name)
            else:
                self.current_stock-=1
                change=self.money_deposited-self.price
                self.money_deposited=0
                return 'Here is your {0} and ${1} change.'.format(self.name,change)

    def deposit(self,money):
        if not self.current_stock:
            return 'Machine is out of stock. Here is your ${0}.'.format(money)
        else:
            self.money_deposited+=money
            return 'Current balance: ${0}'.format(self.money_deposited)


    def restock(self,goods):
        self.current_stock+=goods
        return 'Current {0} stock: {1}'.format(self.name,self.current_stock)
