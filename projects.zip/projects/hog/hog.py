"""CS 61A Presents The Game of Hog."""

from dice import six_sided, four_sided, make_test_dice
from ucb import main, trace, interact
import time
GOAL_SCORE = 100  # The goal of Hog is to score 100 points.

######################
# Phase 1: Simulator #
######################


def roll_dice(num_rolls, dice=six_sided):
    """Simulate rolling the DICE exactly NUM_ROLLS > 0 times. Return the sum of
    the outcomes unless any of the outcomes is 1. In that case, return 1.

    num_rolls:  The number of dice rolls that will be made.
    dice:       A function that simulates a single dice roll outcome.
    """
    # These assert statements ensure that num_rolls is a positive integer.
    assert type(num_rolls) == int, 'num_rolls must be an integer.'
    assert num_rolls > 0, 'Must roll at least once.'
    # BEGIN PROBLEM 1
    "*** YOUR CODE HERE ***"
    sum=0
    isOne=False
    for i in range(num_rolls):
        point=dice()
        if(point!=1):
            sum+=point
        else:
            isOne=True
    if(isOne):
        return 1
    else:
        return sum
    # END PROBLEM 1


def free_bacon(score):
    """Return the points scored from rolling 0 dice (Free Bacon).

    score:  The opponent's current score.
    """
    assert score < 100, 'The game should be over.'
    # BEGIN PROBLEM 2
    "*** YOUR CODE HERE ***"
    if(score>=10):
        bacon=2*(score//10)-(score%10)
        if(bacon>1):
            return bacon
        else:
            return 1
    else:
        return 1
    # END PROBLEM 2


def take_turn(num_rolls, opponent_score, dice=six_sided):
    """Simulate a turn rolling NUM_ROLLS dice, which may be 0 (Free Bacon).
    Return the points scored for the turn by the current player.

    num_rolls:       The number of dice rolls that will be made.
    opponent_score:  The total score of the opponent.
    dice:            A function that simulates a single dice roll outcome.
    """
    # Leave these assert statements here; they help check for errors.
    assert type(num_rolls) == int, 'num_rolls must be an integer.'
    assert num_rolls >= 0, 'Cannot roll a negative number of dice in take_turn.'
    assert num_rolls <= 10, 'Cannot roll more than 10 dice.'
    assert opponent_score < 100, 'The game should be over.'
    # BEGIN PROBLEM 3
    "*** YOUR CODE HERE ***"
    if(num_rolls==0):
        return free_bacon(opponent_score)
    else:
        return roll_dice(num_rolls,dice)
    # END PROBLEM 3


def is_swap(player_score, opponent_score):
    """
    Return whether the current player's score has the same absolute
    difference between its last two digits as the opponent's score.
    """
    # BEGIN PROBLEM 4
    "*** YOUR CODE HERE ***"
    ps=int(str(player_score)[-2:])
    os=int(str(opponent_score)[-2:])
    ps_diff=abs(ps//10 - ps%10)
    os_diff=abs(os//10 - os%10)
    return ps_diff==os_diff
    # END PROBLEM 4


def other(player):
    """Return the other player, for a player PLAYER numbered 0 or 1.

    >>> other(0)
    1
    >>> other(1)
    0
    """
    return 1 - player


def silence(score0, score1):
    """Announce nothing (see Phase 2)."""
    return silence


def play(strategy0, strategy1, score0=0, score1=0, dice=six_sided,
         goal=GOAL_SCORE, say=silence):
    """Simulate a game and return the final scores of both players, with Player
    0's score first, and Player 1's score second.

    A strategy is a function that takes two total scores as arguments (the
    current player's score, and the opponent's score), and returns a number of
    dice that the current player will roll this turn.

    strategy0:  The strategy function for Player 0, who plays first.
    strategy1:  The strategy function for Player 1, who plays second.
    score0:     Starting score for Player 0
    score1:     Starting score for Player 1
    dice:       A function of zero arguments that simulates a dice roll.
    goal:       The game ends and someone wins when this score is reached.
    say:        The commentary function to call at the end of the first turn.
    """
    player = 0  # Which player is about to take a turn, 0 (first) or 1 (second)
    # BEGIN PROBLEM 5
    "*** YOUR CODE HERE ***"

    while score0<goal and score1<goal:
        if(player==0):
            score0+=take_turn(strategy0(score0,score1),score1,dice)
            if(is_swap(score0,score1)):
                score0,score1=score1,score0
        else:
            score1+=take_turn(strategy1(score1,score0),score0,dice)
            if(is_swap(score1,score0)):
                score1,score0=score0,score1
        say=say(score0,score1)
        player=other(player)

    # END PROBLEM 5
    # (note that the indentation for the problem 6 prompt (***YOUR CODE HERE***) might be misleading)
    # BEGIN PROBLEM 6
    "*** YOUR CODE HERE ***"
    # END PROBLEM 6
    return score0, score1


#######################
# Phase 2: Commentary #
#######################


def say_scores(score0, score1):
    """A commentary function that announces the score for each player."""
    print("Player 0 now has", score0, "and Player 1 now has", score1)
    return say_scores

def announce_lead_changes(previous_leader=None):
    """Return a commentary function that announces lead changes.

    >>> f0 = announce_lead_changes()
    >>> f1 = f0(5, 0)
    Player 0 takes the lead by 5
    >>> f2 = f1(5, 12)
    Player 1 takes the lead by 7
    >>> f3 = f2(8, 12)
    >>> f4 = f3(8, 13)
    >>> f5 = f4(15, 13)
    Player 0 takes the lead by 2
    """
    def say(score0, score1):
        if score0 > score1:
            leader = 0
        elif score1 > score0:
            leader = 1
        else:
            leader = None
        if leader != None and leader != previous_leader:
            print('Player', leader, 'takes the lead by', abs(score0 - score1))
        return announce_lead_changes(leader)
    return say

def both(f, g):
    """Return a commentary function that says what f says, then what g says.

    >>> h0 = both(say_scores, announce_lead_changes())
    >>> h1 = h0(10, 0)
    Player 0 now has 10 and Player 1 now has 0
    Player 0 takes the lead by 10
    >>> h2 = h1(10, 6)
    Player 0 now has 10 and Player 1 now has 6
    >>> h3 = h2(6, 18) # Player 0 gets 8 points, then Swine Swap applies
    Player 0 now has 6 and Player 1 now has 18
    Player 1 takes the lead by 12
    """
    def say(score0, score1):
        return both(f(score0, score1), g(score0, score1))
    return say


def announce_highest(who, previous_high=0, previous_score=0):
    """Return a commentary function that announces when WHO's score
    increases by more than ever before in the game.

    >>> f0 = announce_highest(1) # Only announce Player 1 score gains
    >>> f1 = f0(11, 0)
    >>> f2 = f1(11, 9)
    9 point(s)! That's the biggest gain yet for Player 1
    >>> f3 = f2(20, 9)
    >>> f4 = f3(12, 20) # Player 1 gets 3 points, then Swine Swap applies
    11 point(s)! That's the biggest gain yet for Player 1
    >>> f5 = f4(20, 32) # Player 0 gets 20 points, then Swine Swap applies
    12 point(s)! That's the biggest gain yet for Player 1
    >>> f6 = f5(20, 42) # Player 1 gets 10 points; not enough for a new high
    """
    assert who == 0 or who == 1, 'The who argument should indicate a player.'
    # BEGIN PROBLEM 7

    "*** YOUR CODE HERE ***"
    def say(score0,score1):
        ps,ph=previous_score,previous_high
        if(who==0):
            if(score0-ps>ph):
                ph=score0-ps
                print(str(score0-ps)+" point(s)! That's the biggest gain yet for Player "+str(who))
            ps=score0
        else:
            if(score1-ps>ph):
                ph=score1-ps
                print(str(score1-ps)+" point(s)! That's the biggest gain yet for Player "+str(who))
            ps=score1
        return announce_highest(who,ph,ps)
    return say
    # END PROBLEM 7


#######################
# Phase 3: Strategies #
#######################


def always_roll(n):
    """Return a strategy that always rolls N dice.

    A strategy is a function that takes two total scores as arguments (the
    current player's score, and the opponent's score), and returns a number of
    dice that the current player will roll this turn.

    >>> strategy = always_roll(5)
    >>> strategy(0, 0)
    5
    >>> strategy(99, 99)
    5
    """
    def strategy(score, opponent_score):
        return n
    return strategy


def make_averaged(fn, num_samples=1000):
    """Return a function that returns the average value of FN when called.

    To implement this function, you will have to use *args syntax, a new Python
    feature introduced in this project.  See the project description.

    >>> dice = make_test_dice(4, 2, 5, 1)
    >>> averaged_dice = make_averaged(dice, 1000)
    >>> averaged_dice()
    3.0
    """
    # BEGIN PROBLEM 8
    "*** YOUR CODE HERE ***"
    def avg(*args):
        result=0
        for i in range(num_samples):
            result+=fn(*args)
        return result/num_samples
    return avg
    # END PROBLEM 8


def max_scoring_num_rolls(dice=six_sided, num_samples=1000):
    """Return the number of dice (1 to 10) that gives the highest average turn
    score by calling roll_dice with the provided DICE over NUM_SAMPLES times.
    Assume that the dice always return positive outcomes.

    >>> dice = make_test_dice(1, 6)
    >>> max_scoring_num_rolls(dice)
    1
    """
    # BEGIN PROBLEM 9
    "*** YOUR CODE HERE ***"
    avg=[]
    for i in range(1,11):
        averaged=make_averaged(roll_dice,num_samples)
        avg.append(averaged(i,dice))
    #print(avg)
    for i in range(len(avg)):
        if avg[i]==max(avg):
            return i+1
    # END PROBLEM 9


def winner(strategy0, strategy1):
    """Return 0 if strategy0 wins against strategy1, and 1 otherwise."""
    score0, score1 = play(strategy0, strategy1)
    global RISK
    RISK=3
    if score0 > score1:
        return 0
    else:
        return 1


def average_win_rate(strategy, baseline=always_roll(4)):
    """Return the average win rate of STRATEGY against BASELINE. Averages the
    winrate when starting the game as player 0 and as player 1.
    """
    win_rate_as_player_0 = 1 - make_averaged(winner)(strategy, baseline)
    win_rate_as_player_1 = make_averaged(winner)(baseline, strategy)

    return (win_rate_as_player_0 + win_rate_as_player_1) / 2


def run_experiments():
    final=[]
    """Run a series of strategy experiments and report results."""
    if False:  # Change to False when done finding max_scoring_num_rolls
        six_sided_max = max_scoring_num_rolls(six_sided)
        print('Max scoring num rolls for six-sided dice:', six_sided_max)

    if True:  # Change to True to test always_roll(8)
        print('always_roll(8) win rate:', average_win_rate(always_roll(8)))

    if True:  # Change to True to test bacon_strategy
        print('bacon_strategy win rate:', average_win_rate(bacon_strategy))

    if True:  # Change to True to test swap_strategy
        print('swap_strategy win rate:', average_win_rate(swap_strategy))

    if True:  # Change to True to test final_strategy
        #final.append(average_win_rate(swap_strategy)(margin=4,num_rolls=4))
        print('final_strategy win rate:', average_win_rate(final_strategy))

    "*** You may add additional experiments as you wish ***"


def bacon_strategy(score, opponent_score, margin=8, num_rolls=4):
    """This strategy rolls 0 dice if that gives at least MARGIN points, and
    rolls NUM_ROLLS otherwise.
    """
    # BEGIN PROBLEM 10
    assert opponent_score<100 and score<100, 'The game should be over.'
    if(free_bacon(opponent_score)>=margin):
        return 0
    else:
        return num_rolls
    # Replace this statement
    # END PROBLEM 10

def swap_strategy(score, opponent_score, margin=8, num_rolls=4):
    """This strategy rolls 0 dice when it triggers a beneficial swap. It also
    rolls 0 dice if it gives at least MARGIN points and does not trigger a
    non-beneficial swap. Otherwise, it rolls NUM_ROLLS.
    """
    # BEGIN PROBLEM 11

    scoreZero=score+free_bacon(opponent_score)
    if(bacon_strategy(score, opponent_score, margin, num_rolls)==0):
        if(scoreZero>opponent_score and is_swap(scoreZero,opponent_score)==True):
            return num_rolls
        else:
            return 0
    else:
        if(is_swap(scoreZero,opponent_score)==True):
            if(scoreZero>opponent_score):
                return num_rolls
            else:
                return 0
        else:
            return num_rolls
SAFE=0
def swap_strategy2(score, opponent_score, margin=8, num_rolls=4, safety=SAFE,shouldPrint=True):
    """This strategy rolls 0 dice when it triggers a beneficial swap. It also
    rolls 0 dice if it gives at least MARGIN points and does not trigger a
    non-beneficial swap. Otherwise, it rolls NUM_ROLLS.
    """
    # BEGIN PROBLEM 11
    global RISK
    if(shouldPrint):
        print('current risk',RISK, 'current score',score,'VS',opponent_score)
    RISK=RISK-1
    #RISK=1
    if(shouldPrint):
        print('updated risk',RISK, 'current score',score,'VS',opponent_score)

    scoreZero=score+free_bacon(opponent_score)
    if(bacon_strategy(score, opponent_score, margin, num_rolls)==0):
        if(scoreZero>opponent_score and is_swap(scoreZero,opponent_score)==True):
            return num_rolls
        else:
            return 0
    else:
        if(is_swap(scoreZero,opponent_score)==True):
            if(scoreZero>opponent_score):
                return num_rolls
            else:
                return 0
        else:
            return num_rolls
    # Replace this statement
    # END PROBLEM 11
global RISK
RISK=5
MAX_RISK=10



def final_strategy(score=0, opponent_score=0, risklevel=RISK, safety=SAFE, margin=8, num_rolls=3,shouldPrint=True):
    """Write a brief description of your final strategy.

    *** YOUR DESCRIPTION HERE ***
    """
    '''
    chance of getting 1
    roll 1 dice's probability 0.16666666666666663
    roll 2 dice's probability 0.30555555555555547
    roll 3 dice's probability 0.42129629629629617
    roll 4 dice's probability 0.5177469135802468
    roll 5 dice's probability 0.598122427983539
    roll 6 dice's probability 0.6651020233196159
    roll 7 dice's probability 0.7209183527663465
    roll 8 dice's probability 0.7674319606386221
    roll 9 dice's probability 0.8061933005321851
    roll 10 dice's probability 0.8384944171101543

    '''
    #different risk dude!
    global RISK
    if(shouldPrint):
        print('current risk',RISK, 'current score',score,'VS',opponent_score)
    risklevel,safety,health=RISK,SAFE,(RISK+SAFE)//2

    #risklevel stands for the risk evaluated after you return new_risk
    #health stands for the most conservative index
    #health is the average
    if(score==opponent_score):
        if(score==0):
            return 9
        else:
            if(MAX_RISK-risklevel<risklevel-safety):
                return swap_strategy2(score, opponent_score, margin, num_rolls)
            else:
                risklevel+=1
    elif(score<opponent_score):
        if(MAX_RISK-risklevel<risklevel-safety):
            return swap_strategy2(score, opponent_score, margin+2, num_rolls)
        else:
            risklevel+=3
    else:
        if(MAX_RISK-risklevel<risklevel-safety):
            return swap_strategy2(score, opponent_score, margin, num_rolls)
        else:
            risklevel+=2


    if(shouldPrint):
        print('updated risk',RISK, 'current score',score,'VS',opponent_score)
    RISK=risklevel
    return risklevel
    '''if risklevel<=0:
        #RISK=1
        return 1
    elif risklevel>10:
        #RISK=10
        return 10
    else:
        RISK=risklevel
        return risklevel+4'''








##########################
# Command Line Interface #
##########################

# NOTE: Functions in this section do not need to be changed. They use features
# of Python not yet covered in the course.


@main
def run(*args):

    """Read in the command-line argument and calls corresponding functions.

    This function uses Python syntax/techniques not yet covered in this course.
    """
    import argparse
    parser = argparse.ArgumentParser(description="Play Hog")
    parser.add_argument('--run_experiments', '-r', action='store_true',
                        help='Runs strategy experiments')

    args = parser.parse_args()

    if args.run_experiments:
        run_experiments()
